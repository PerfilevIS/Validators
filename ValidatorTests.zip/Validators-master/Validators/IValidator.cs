﻿namespace Validators
{
    public interface IValidator
    {
        bool Validate(string validateObject);
    }
}
